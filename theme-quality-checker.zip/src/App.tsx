/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, FC } from 'react';
import { 
  Clapperboard, 
  Menu, 
  X, 
  Film, 
  Zap, 
  Target, 
  Layout, 
  CheckCircle2, 
  Mail, 
  MapPin, 
  PhoneCall, 
  Play,
  ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface WorkItem {
  brand: string;
  title: string;
  color: string;
  videoUrl?: string;
  poster?: string;
}

const WorkCard: FC<{ ad: WorkItem; index: number }> = ({ ad, index }) => {
  const [isHovered, setIsHovered] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      if (isHovered) {
        videoRef.current.play().catch(() => {});
      } else {
        videoRef.current.pause();
        videoRef.current.currentTime = 0;
      }
    }
  }, [isHovered]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative aspect-[9/16] rounded-3xl overflow-hidden border border-white/5 cursor-pointer bg-black"
    >
      {ad.videoUrl && (
        <motion.video
          ref={videoRef}
          muted
          loop
          playsInline
          preload="auto"
          poster={ad.poster}
          initial={{ opacity: 0 }}
          animate={{ opacity: isHovered ? 1 : 0.3 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
          className="absolute inset-0 w-full h-full object-cover"
        >
          <source src={ad.videoUrl} type="video/mp4" />
        </motion.video>
      )}
      
      {/* Dynamic Overlay */}
      <motion.div 
        initial={{ opacity: 0.6 }}
        animate={{ 
          opacity: isHovered ? 0 : 0.6,
          scale: isHovered ? 1.05 : 1
        }}
        transition={{ duration: 0.6, ease: "easeInOut" }}
        className={`absolute inset-0 bg-linear-to-br ${ad.color} pointer-events-none z-0`}
      />
      
      <div className="absolute inset-0 p-8 flex flex-col items-center justify-center text-center space-y-6 z-10">
        <motion.div 
          animate={{ 
            scale: isHovered ? 1.15 : 1,
            backgroundColor: isHovered ? "#ffd700" : "rgba(255, 215, 0, 0.82)"
          }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
          className="w-16 h-16 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(0,0,0,0.3)] group-hover:shadow-gold/40 transition-shadow"
        >
          <Play className="w-7 h-7 text-black ml-1 fill-current" />
        </motion.div>
        <motion.div
          animate={{ y: isHovered ? 0 : 10, opacity: isHovered ? 1 : 0.7 }}
          transition={{ duration: 0.4 }}
        >
          <h4 className="text-gold font-bold text-xs tracking-widest uppercase mb-2">{ad.brand}</h4>
          <p className="text-white/80 text-sm italic font-light leading-relaxed max-w-[200px]">{ad.title}</p>
        </motion.div>
      </div>

      {/* Decorative border glow on hover */}
      <motion.div
        animate={{ opacity: isHovered ? 1 : 0 }}
        className="absolute inset-0 border-2 border-gold/30 rounded-3xl pointer-events-none"
      />
    </motion.div>
  );
};

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [formStatus, setFormStatus] = useState<'idle' | 'sending' | 'success'>('idle');
  const [showcasePlaying, setShowcasePlaying] = useState(false);
  const showcaseVideoRef = useRef<HTMLVideoElement>(null);

  // --- CONFIG: ADD YOUR VIDEOS HERE ---
  const showcaseVideoUrl = "https://vjs.zencdn.net/v/oceans.mp4"; 
  const ads: WorkItem[] = [
    { 
      brand: 'Solaara Jewels', 
      title: 'Before The Vows, Light.', 
      color: 'from-[#1a1200] to-[#3a2800]', 
      videoUrl: 'https://vjs.zencdn.net/v/oceans.mp4',
      poster: 'https://images.unsplash.com/photo-1549439602-43ebca2327af?auto=format&fit=crop&q=80&w=400'
    },
    { 
      brand: 'Whole The Truth', 
      title: 'What You See Is What You Eat.', 
      color: 'from-[#1a0e00] to-[#3a2000]', 
      videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
      poster: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&q=80&w=400'
    },
    { 
      brand: 'Lumé Jewels', 
      title: 'Modern Royalty — Editorial', 
      color: 'from-[#180d00] to-[#2e1800]', 
      videoUrl: 'https://media.w3.org/2010/05/sintel/trailer_hd.mp4',
      poster: 'https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&q=80&w=400'
    },
    { 
      brand: 'boAt', 
      title: 'Poolside. Volume High.', 
      color: 'from-[#0e0c00] to-[#1c1800]', 
      videoUrl: 'https://media.w3.org/2010/05/bunny/movie.mp4',
      poster: 'https://images.unsplash.com/photo-1519817650390-64a93db51149?auto=format&fit=crop&q=80&w=400'
    },
  ];
  // ------------------------------------

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleWatchDemo = () => {
    setShowcasePlaying(true);
    const element = document.getElementById('our-work');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    // Small delay to ensure the video element is mounted before playing
    setTimeout(() => {
      if (showcaseVideoRef.current) {
        showcaseVideoRef.current.play().catch(e => console.error("Autoplay failed:", e));
      }
    }, 500);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('sending');
    setTimeout(() => {
      setFormStatus('success');
      (e.target as HTMLFormElement).reset();
      setTimeout(() => setFormStatus('idle'), 3000);
    }, 1500);
  };

  return (
    <div className="min-h-screen selection:bg-gold selection:text-black">
      <div className="bg-glow" />

      {/* Navigation */}
      <header className={`fixed w-full z-50 top-0 transition-all duration-300 ${scrolled ? 'py-3 bg-dark-bg/80 backdrop-blur-xl border-b border-gold/10' : 'py-6 bg-transparent'}`}>
        <div className="container mx-auto px-6 flex justify-between items-center">
          <a href="#" className="text-2xl font-bold tracking-tighter flex items-center gap-2">
            <Clapperboard className="text-gold w-8 h-8" />
            <span>Vedanta <span className="text-gold">Films</span></span>
          </a>
          
          <nav className="hidden md:flex items-center space-x-8 text-sm font-medium">
            <a href="#our-work" className="hover:text-gold transition-colors">Our Work</a>
            <a href="#services" className="hover:text-gold transition-colors">Services</a>
            <a href="#pricing" className="hover:text-gold transition-colors">Pricing</a>
            <a href="#contact" className="px-5 py-2 border border-gold rounded-full text-gold hover:bg-gold hover:text-black transition-all">Contact</a>
          </nav>

          <button onClick={() => setIsMenuOpen(true)} className="md:hidden text-white">
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            className="fixed inset-0 z-[60] bg-dark-bg p-6 flex flex-col md:hidden"
          >
            <div className="flex justify-between items-center mb-12">
              <div className="text-2xl font-bold tracking-tighter flex items-center gap-2">
                <Clapperboard className="text-gold w-8 h-8" />
                <span>Vedanta <span className="text-gold">Films</span></span>
              </div>
              <button onClick={() => setIsMenuOpen(false)} className="text-white">
                <X className="w-8 h-8" />
              </button>
            </div>
            
            <nav className="flex flex-col space-y-8 text-3xl font-bold">
              <a href="#our-work" onClick={() => setIsMenuOpen(false)} className="hover:text-gold transition-colors">Our Work</a>
              <a href="#services" onClick={() => setIsMenuOpen(false)} className="hover:text-gold transition-colors">Services</a>
              <a href="#pricing" onClick={() => setIsMenuOpen(false)} className="hover:text-gold transition-colors">Pricing</a>
              <a href="#contact" onClick={() => setIsMenuOpen(false)} className="text-gold font-bold">Contact</a>
            </nav>
            
            <div className="mt-auto pb-12">
              <p className="text-gray-500 text-sm mb-4 italic">Ready to automate your brand's growth?</p>
              <div className="flex gap-4">
                <div className="w-10 h-10 border border-white/10 rounded-full flex items-center justify-center">
                  <Mail className="w-5 h-5 text-gold" />
                </div>
                <div className="w-10 h-10 border border-white/10 rounded-full flex items-center justify-center">
                  <PhoneCall className="w-5 h-5 text-gold" />
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center pt-20 px-6 overflow-hidden">
        <div className="container mx-auto text-center relative z-10">
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 0.1, scale: 1 }}
            className="absolute -top-40 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-gold blur-[160px] rounded-full pointer-events-none"
          />
          
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-block px-4 py-1.5 mb-6 text-[10px] sm:text-xs font-semibold tracking-widest uppercase border border-white/10 rounded-full bg-white/5"
          >
            Modern Growth Solutions for Business
          </motion.span>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl sm:text-6xl md:text-8xl font-bold mb-8 tracking-tight leading-[1.1]"
          >
            Scale Your Brand With <br />
            <span className="gold-text italic">AI-Powered</span> Marketing
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-gray-400 text-base sm:text-lg md:text-xl max-w-2xl mx-auto mb-12"
          >
            We bridge the gap between high-end film production and ROI-driven digital marketing. Automate your leads while looking like a premium brand.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center"
          >
            <a href="#contact" className="btn-primary px-10 py-5 rounded-full font-bold w-full sm:w-auto text-center text-lg shadow-xl shadow-gold/20">
              Get Free Strategy Session
            </a>
            <button 
              onClick={handleWatchDemo}
              className="flex items-center gap-2 px-8 py-5 border border-white/10 rounded-full font-semibold hover:border-gold hover:text-gold transition-all"
            >
              <Zap className="w-5 h-5 text-gold" />
              Watch Demo
            </button>
            <a href="#" className="group flex items-center gap-3 text-white hover:text-gold transition-colors px-6 py-4">
              <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-gold/10 transition-all">
                <Play className="w-5 h-5 fill-current" />
              </div>
              <span className="font-semibold">Watch Showreel</span>
            </a>
          </motion.div>
        </div>
      </section>

      {/* AI Ad Showcase */}
      <section id="our-work" className="py-32 px-6 bg-[#060606]">
        <div className="container mx-auto max-w-6xl">
          <div className="mb-16">
            <span className="inline-block font-bold text-[11px] tracking-[0.2em] uppercase bg-gold text-black px-3 py-1 rounded mb-4">Our Work</span>
            <h2 className="text-3xl md:text-5xl font-bold mb-4 tracking-tight">See What <span className="gold-text italic">AI</span> Creates</h2>
            <p className="text-gray-500 max-w-lg leading-relaxed font-light">Watch how we craft scroll-stopping ads for top brands — entirely with AI. Everything below is 100% AI-generated.</p>
          </div>

          <div 
            className={`relative group aspect-video bg-card-bg rounded-[40px] overflow-hidden border transition-all duration-700 mb-24 bg-black ${showcasePlaying ? 'border-gold shadow-[0_0_80px_rgba(255,215,0,0.15)] ring-8 ring-gold/10' : 'border-white/5 cursor-pointer hover:border-gold/50'}`}
          >
            {showcasePlaying && showcaseVideoUrl ? (
              <div className="relative w-full h-full">
                <video 
                  ref={showcaseVideoRef}
                  autoPlay 
                  muted
                  controls 
                  preload="auto"
                  playsInline
                  className="w-full h-full object-contain accent-gold"
                >
                  <source src={showcaseVideoUrl} type="video/mp4" />
                </video>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowcasePlaying(false);
                  }}
                  className="absolute top-6 right-6 z-20 w-12 h-12 bg-black/60 backdrop-blur-md border border-white/10 rounded-full flex items-center justify-center text-white hover:bg-gold hover:text-black hover:border-gold transition-all shadow-lg"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            ) : (
              <div 
                onClick={() => setShowcasePlaying(true)}
                className="w-full h-full"
              >
                <div className="absolute inset-0 bg-linear-to-br from-gold/10 via-gold/5 to-transparent z-0 opacity-40" />
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,215,0,0.04)_1px,transparent_1px),linear-gradient(90deg,rgba(255,215,0,0.04)_1px,transparent_1px)] bg-[size:60px_60px] opacity-20" />
                
                <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center z-10">
                  <span className="absolute top-8 left-8 bg-gold/10 border border-gold/30 rounded-lg px-4 py-1.5 text-[11px] font-bold text-gold tracking-widest">16 : 9</span>
                  <span className="absolute bottom-8 right-8 bg-black/70 border border-white/10 rounded-lg px-4 py-1.5 text-xs font-semibold text-white tracking-widest">SHOWCASE VIDEO</span>
                  
                  <div className="mb-6 space-y-2">
                    <small className="uppercase tracking-[0.3em] text-gold font-bold text-[10px]">Workshop Overview</small>
                    <h3 className="text-2xl sm:text-4xl md:text-5xl font-bold leading-tight">Everything below <br /> is <span className="gold-text italic">AI.</span></h3>
                  </div>
                  
                  <motion.div 
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-20 h-20 bg-gold rounded-full flex items-center justify-center shadow-[0_0_40px_rgba(255,215,0,0.4)] group-hover:shadow-[0_0_60px_rgba(255,215,0,0.6)] transition-all mb-8"
                  >
                    <Play className="w-8 h-8 text-black ml-1.5 fill-current" />
                  </motion.div>
                  
                  <p className="text-white/40 text-sm max-w-sm font-light">Watch how we create cinematic experiences for top Indian brands using generative AI models.</p>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {ads.map((ad, i) => (
              <WorkCard key={i} ad={ad} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="py-32 px-6 bg-dark-bg">
        <div className="container mx-auto">
          <div className="text-center mb-24 max-w-2xl mx-auto">
            <h2 className="text-4xl md:text-6xl font-bold mb-6 tracking-tight">The Growth <span className="gold-text italic">Engine</span></h2>
            <div className="w-24 h-1 bg-gold mx-auto mb-8" />
            <p className="text-gray-500 text-lg font-light">Custom marketing stacks that turn your visual assets into a consistent stream of customer bookings.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Film, title: 'Premium Reels', desc: 'High-conversion short-form content tailored for Instagram to capture attention instantly.' },
              { icon: Zap, title: 'Lead Automation', desc: 'Our AI bots reply to every DM and comment instantly, converting window shoppers into paid bookings.' },
              { icon: Target, title: 'Meta Ad Engine', desc: 'Laser-targeted advertising campaigns designed for salons, clinics, and professionals.' },
              { icon: Layout, title: 'Smart Funnels', desc: 'Beautiful landing pages optimized for speed and conversion. No more dead-end websites.' },
            ].map((s, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="service-card p-10 rounded-[40px]"
              >
                <div className="w-14 h-14 bg-gold/10 rounded-2xl flex items-center justify-center mb-8 border border-gold/20">
                  <s.icon className="text-gold w-7 h-7" />
                </div>
                <h3 className="text-2xl font-bold mb-4">{s.title}</h3>
                <p className="text-gray-500 leading-relaxed font-light">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-32 px-6 bg-[#060606] relative overflow-hidden">
        <div className="container mx-auto">
          <div className="text-center mb-24">
            <h2 className="text-4xl md:text-6xl font-bold mb-6 tracking-tight">Investment Plans</h2>
            <p className="text-gray-500 text-lg">Transparent pricing for every stage of your business growth.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto items-center">
            {/* Starter */}
            <div className="pricing-card p-10 rounded-[32px] border border-white/5 opacity-80 scale-95">
              <h3 className="text-xl font-bold mb-2">Starter</h3>
              <div className="text-5xl font-bold mb-8 tracking-tighter">₹12,499<span className="text-sm font-normal text-gray-500">/mo</span></div>
              <ul className="space-y-5 mb-10 text-gray-500 font-light">
                <li className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-gold shrink-0" /> 10 Custom Post Designs</li>
                <li className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-gold shrink-0" /> 4 Reels per month</li>
                <li className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-gold shrink-0" /> Basic Lead Capture</li>
              </ul>
              <a href="#contact" className="block w-full py-4 rounded-full border border-white/10 hover:bg-white/5 transition-all font-bold text-center">Get Started</a>
            </div>

            {/* Growth Pro */}
            <div className="pricing-card pricing-card-featured p-12 rounded-[40px] shadow-[0_40px_100px_rgba(0,0,0,0.8)]">
              <div className="absolute top-6 right-6 bg-gold text-black text-[10px] font-black px-4 py-1 rounded-full uppercase tracking-widest">Most Popular</div>
              <h3 className="text-xl font-bold mb-2 text-gold">Growth Pro</h3>
              <div className="text-6xl font-bold mb-8 tracking-tighter">₹24,999<span className="text-sm font-normal text-gray-400">/mo</span></div>
              <ul className="space-y-5 mb-12">
                <li className="flex items-center gap-3 font-medium"><CheckCircle2 className="w-5 h-5 text-gold shrink-0" /> 15 High-End Designs</li>
                <li className="flex items-center gap-3 font-medium"><CheckCircle2 className="w-5 h-5 text-gold shrink-0" /> 8 Reels (Cinematic AI)</li>
                <li className="flex items-center gap-3 font-medium"><CheckCircle2 className="w-5 h-5 text-gold shrink-0" /> AI Auto-Responder Bots</li>
                <li className="flex items-center gap-3 font-medium"><CheckCircle2 className="w-5 h-5 text-gold shrink-0" /> Ads Expert Management</li>
              </ul>
              <a href="#contact" className="w-full py-5 rounded-full bg-gold text-black font-black text-lg hover:shadow-gold/40 hover:shadow-2xl transition-all flex items-center justify-center gap-3 group">
                Select Plan <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>

            {/* Dominance */}
            <div className="pricing-card p-10 rounded-[32px] border border-white/5 opacity-80 scale-95">
              <h3 className="text-xl font-bold mb-2">Dominance</h3>
              <div className="text-5xl font-bold mb-8 tracking-tighter">₹49,999<span className="text-sm font-normal text-gray-500">/mo</span></div>
              <ul className="space-y-5 mb-10 text-gray-500 font-light">
                <li className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-gold shrink-0" /> Unlimited Graphic Design</li>
                <li className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-gold shrink-0" /> Full Brand Identity Suite</li>
                <li className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-gold shrink-0" /> Multi-Channel Funnel Build</li>
                <li className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-gold shrink-0" /> Priority Account Support</li>
              </ul>
              <a href="#contact" className="block w-full py-4 rounded-full border border-white/10 hover:bg-white/5 transition-all font-bold text-center">Contact Sales</a>
            </div>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-32 px-6 relative bg-dark-bg">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div>
              <motion.h2 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                className="text-5xl sm:text-7xl font-bold mb-8 tracking-tighter"
              >
                Ready to <br /><span className="gold-text">Dominate?</span>
              </motion.h2>
              <p className="text-gray-400 text-lg mb-12 font-light leading-relaxed max-w-md">Schedule a free 15-minute audit of your current social media and ads strategy. Let us show you the gap between where you are and where AI can take you.</p>
              
              <div className="space-y-8">
                <div className="flex items-center gap-6 group cursor-pointer">
                  <div className="w-14 h-14 bg-gold/5 rounded-2xl flex items-center justify-center border border-white/5 group-hover:border-gold/30 transition-all">
                    <Mail className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <p className="text-gray-500 text-sm font-bold uppercase tracking-widest mb-1">Email Us</p>
                    <p className="text-xl font-medium">hello@vedantafilms.com</p>
                  </div>
                </div>
                <div className="flex items-center gap-6 group cursor-pointer">
                  <div className="w-14 h-14 bg-gold/5 rounded-2xl flex items-center justify-center border border-white/5 group-hover:border-gold/30 transition-all">
                    <MapPin className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <p className="text-gray-500 text-sm font-bold uppercase tracking-widest mb-1">Office</p>
                    <p className="text-xl font-medium">Andheri West, Mumbai, India</p>
                  </div>
                </div>
              </div>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="bg-[#111] p-10 sm:p-14 rounded-[48px] border border-white/5 shadow-2xl relative"
            >
              <form onSubmit={handleFormSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 ml-4">Full Name</label>
                    <input type="text" placeholder="John Doe" className="w-full bg-[#1a1a1a] border border-white/10 rounded-2xl p-5 focus:outline-none focus:border-gold transition-all text-white placeholder:text-gray-700" required />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 ml-4">Phone Number</label>
                    <input type="tel" placeholder="+91 98765 43210" className="w-full bg-[#1a1a1a] border border-white/10 rounded-2xl p-5 focus:outline-none focus:border-gold transition-all text-white placeholder:text-gray-700" required />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 ml-4">Business Email</label>
                  <input type="email" placeholder="john@company.com" className="w-full bg-[#1a1a1a] border border-white/10 rounded-2xl p-5 focus:outline-none focus:border-gold transition-all text-white placeholder:text-gray-700" required />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 ml-4">Industry Type</label>
                  <select className="w-full bg-[#1a1a1a] border border-white/10 rounded-2xl p-5 focus:outline-none focus:border-gold transition-all text-gray-400 appearance-none">
                    <option value="">Select Industry</option>
                    <option value="salon">Salon & Spa</option>
                    <option value="real-estate">Real Estate</option>
                    <option value="clinic">Clinic/Hospital</option>
                    <option value="other">Other Business</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 ml-4">Your Goals</label>
                  <textarea placeholder="Tell us what you want to achieve..." rows={4} className="w-full bg-[#1a1a1a] border border-white/10 rounded-3xl p-5 focus:outline-none focus:border-gold transition-all text-white placeholder:text-gray-700"></textarea>
                </div>

                <button 
                  disabled={formStatus !== 'idle'}
                  className={`w-full py-6 rounded-2xl font-black text-lg transition-all flex items-center justify-center gap-3 
                    ${formStatus === 'success' ? 'bg-green-500 text-white' : 'btn-primary'}
                    ${formStatus === 'sending' ? 'opacity-70 cursor-wait' : ''}`}
                >
                  {formStatus === 'idle' && <>Request Free Audit <ArrowRight className="w-5 h-5" /></>}
                  {formStatus === 'sending' && "Processing..."}
                  {formStatus === 'success' && "Sent Successfully!"}
                </button>
              </form>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 px-6 border-t border-white/5 bg-black">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-12 mb-16">
            <div className="text-3xl font-bold tracking-tighter flex items-center gap-2">
              <Clapperboard className="text-gold w-10 h-10" />
              <span>Vedanta <span className="text-gold">Films</span></span>
            </div>
            
            <div className="flex gap-10 text-gray-500 font-bold text-xs tracking-widest uppercase">
              <a href="#" className="hover:text-gold transition-colors">Instagram</a>
              <a href="#" className="hover:text-gold transition-colors">YouTube</a>
              <a href="#" className="hover:text-gold transition-colors">LinkedIn</a>
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center gap-6 pt-12 border-t border-white/5">
            <p className="text-gray-600 text-sm font-light italic">
              &copy; 2026 Vedanta Films. Empowering brands through cinematic AI.
            </p>
            <div className="flex gap-8 text-gray-700 text-xs uppercase tracking-widest">
              <a href="#" className="hover:text-white transition-all">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-all">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
